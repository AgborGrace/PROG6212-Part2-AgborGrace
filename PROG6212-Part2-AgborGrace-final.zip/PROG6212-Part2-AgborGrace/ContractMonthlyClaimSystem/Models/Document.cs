﻿namespace ContractMonthlyClaimSystem.Models
{
    public class Document
    {
    }
}
