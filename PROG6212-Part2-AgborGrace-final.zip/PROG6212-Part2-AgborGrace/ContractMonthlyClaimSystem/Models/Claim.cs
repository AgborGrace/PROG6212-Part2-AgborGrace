﻿using System.ComponentModel.DataAnnotations;
using System.Reflection.Metadata;

namespace ContractMonthlyClaimSystem.Models
{
    public class Claim
    {
        public int ClaimId { get; set; }

        [Required(ErrorMessage = "Lecturer name is required")]
        [StringLength(100, ErrorMessage = "Name cannot exceed 100 characters")]
        public string LecturerName { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email address")]
        public string LecturerEmail { get; set; }

        [Required(ErrorMessage = "Month and Year is required")]
        [DataType(DataType.Date)]
        public DateTime MonthYear { get; set; }

        [Required(ErrorMessage = "Hours worked is required")]
        [Range(1, 744, ErrorMessage = "Hours must be between 1 and 744 (max hours in a month)")]
        public decimal HoursWorked { get; set; }

        [Required(ErrorMessage = "Hourly rate is required")]
        [Range(50, 5000, ErrorMessage = "Hourly rate must be between R50 and R5000")]
        [DataType(DataType.Currency)]
        public decimal HourlyRate { get; set; }

        [StringLength(500, ErrorMessage = "Notes cannot exceed 500 characters")]
        public string? AdditionalNotes { get; set; }

        // Calculated field
        public decimal TotalAmount => HoursWorked * HourlyRate;

        [Required]
        public ClaimStatus Status { get; set; } = ClaimStatus.Pending;

        public DateTime SubmittedAt { get; set; } = DateTime.Now;

        public DateTime? CoordinatorReviewedAt { get; set; }
        public string? CoordinatorComments { get; set; }

        public DateTime? ManagerReviewedAt { get; set; }
        public string? ManagerComments { get; set; }

        // Navigation property for documents
        public List<Document> Documents { get; set; } = new List<Document>();
    }

    public enum ClaimStatus
    {
        Pending,
        CoordinatorVerified,
        CoordinatorRejected,
        ManagerApproved,
        ManagerRejected
    }
}