﻿using System.Security.Cryptography;
using System.Text;

namespace ContractMonthlyClaimSystem.Services
{
    public interface IFileEncryptionService
    {
        Task<string> EncryptFileAsync(IFormFile file, string savePath);
        Task<byte[]> DecryptFileAsync(string encryptedFilePath);
    }

    public class FileEncryptionService : IFileEncryptionService
    {
        // Use a secure key in production - this should be in configuration/environment variables
        private readonly byte[] _encryptionKey;
        private readonly ILogger<FileEncryptionService> _logger;

        public FileEncryptionService(ILogger<FileEncryptionService> logger)
        {
            _logger = logger;
            // In production, load this from secure configuration
            _encryptionKey = Encoding.UTF8.GetBytes("CMCS2024SecureKey32CharactersLong!");
        }

        public async Task<string> EncryptFileAsync(IFormFile file, string savePath)
        {
            try
            {
                using var aes = Aes.Create();
                aes.Key = _encryptionKey;
                aes.GenerateIV();

                var encryptor = aes.CreateEncryptor(aes.Key, aes.IV);

                var fileName = $"{Guid.NewGuid()}_{file.FileName}.enc";
                var fullPath = Path.Combine(savePath, fileName);

                // Ensure directory exists
                Directory.CreateDirectory(savePath);

                using (var fileStream = new FileStream(fullPath, FileMode.Create))
                {
                    // Write IV to the beginning of the file
                    await fileStream.WriteAsync(aes.IV, 0, aes.IV.Length);

                    using (var cryptoStream = new CryptoStream(fileStream, encryptor, CryptoStreamMode.Write))
                    using (var inputStream = file.OpenReadStream())
                    {
                        await inputStream.CopyToAsync(cryptoStream);
                    }
                }

                _logger.LogInformation($"File encrypted successfully: {fileName}");
                return fullPath;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error encrypting file");
                throw new InvalidOperationException("Failed to encrypt file", ex);
            }
        }

        public async Task<byte[]> DecryptFileAsync(string encryptedFilePath)
        {
            try
            {
                if (!File.Exists(encryptedFilePath))
                {
                    throw new FileNotFoundException("Encrypted file not found", encryptedFilePath);
                }

                using var aes = Aes.Create();
                aes.Key = _encryptionKey;

                using var fileStream = new FileStream(encryptedFilePath, FileMode.Open);

                // Read IV from the beginning of the file
                var iv = new byte[aes.IV.Length];
                await fileStream.ReadAsync(iv, 0, iv.Length);
                aes.IV = iv;

                var decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

                using var cryptoStream = new CryptoStream(fileStream, decryptor, CryptoStreamMode.Read);
                using var memoryStream = new MemoryStream();

                await cryptoStream.CopyToAsync(memoryStream);

                _logger.LogInformation($"File decrypted successfully: {encryptedFilePath}");
                return memoryStream.ToArray();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error decrypting file");
                throw new InvalidOperationException("Failed to decrypt file", ex);
            }
        }
    }
}