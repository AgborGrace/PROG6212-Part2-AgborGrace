﻿using System.Reflection.Metadata;
using ContractMonthlyClaimSystem.Models;

namespace ContractMonthlyClaimSystem.Data
{
    public interface IDataStore
    {
        List<Claim> GetAllClaims();
        Claim? GetClaimById(int id);
        void AddClaim(Claim claim);
        void UpdateClaim(Claim claim);
        List<Claim> GetPendingClaims();
        List<Claim> GetCoordinatorVerifiedClaims();
        void AddDocument(Document document);
        List<Document> GetDocumentsByClaimId(int claimId);
        Document? GetDocumentById(int id);
    }

    public class InMemoryDataStore : IDataStore
    {
        private static List<Claim> _claims = new List<Claim>();
        private static List<Document> _documents = new List<Document>();
        private static int _claimIdCounter = 1;
        private static int _documentIdCounter = 1;
        private static readonly object _lock = new object();

        public InMemoryDataStore()
        {
            // Initialize with sample data if empty
            if (_claims.Count == 0)
            {
                InitializeSampleData();
            }
        }

        private void InitializeSampleData()
        {
            lock (_lock)
            {
                _claims.Add(new Claim
                {
                    ClaimId = _claimIdCounter++,
                    LecturerName = "Dr. John Smith",
                    LecturerEmail = "john.smith@university.ac.za",
                    MonthYear = new DateTime(2025, 9, 1),
                    HoursWorked = 120,
                    HourlyRate = 450,
                    AdditionalNotes = "Teaching Advanced Programming modules",
                    Status = ClaimStatus.Pending,
                    SubmittedAt = DateTime.Now.AddDays(-5)
                });

                _claims.Add(new Claim
                {
                    ClaimId = _claimIdCounter++,
                    LecturerName = "Prof. Sarah Johnson",
                    LecturerEmail = "sarah.johnson@university.ac.za",
                    MonthYear = new DateTime(2025, 9, 1),
                    HoursWorked = 100,
                    HourlyRate = 500,
                    AdditionalNotes = "Database Systems lectures and tutorials",
                    Status = ClaimStatus.CoordinatorVerified,
                    SubmittedAt = DateTime.Now.AddDays(-8),
                    CoordinatorReviewedAt = DateTime.Now.AddDays(-3),
                    CoordinatorComments = "Verified - All documentation in order"
                });
            }
        }

        public List<Claim> GetAllClaims()
        {
            lock (_lock)
            {
                return _claims.OrderByDescending(c => c.SubmittedAt).ToList();
            }
        }

        public Claim? GetClaimById(int id)
        {
            lock (_lock)
            {
                return _claims.FirstOrDefault(c => c.ClaimId == id);
            }
        }

        public void AddClaim(Claim claim)
        {
            lock (_lock)
            {
                claim.ClaimId = _claimIdCounter++;
                claim.SubmittedAt = DateTime.Now;
                _claims.Add(claim);
            }
        }

        public void UpdateClaim(Claim claim)
        {
            lock (_lock)
            {
                var existingClaim = _claims.FirstOrDefault(c => c.ClaimId == claim.ClaimId);
                if (existingClaim != null)
                {
                    var index = _claims.IndexOf(existingClaim);
                    _claims[index] = claim;
                }
            }
        }

        public List<Claim> GetPendingClaims()
        {
            lock (_lock)
            {
                return _claims
                    .Where(c => c.Status == ClaimStatus.Pending)
                    .OrderByDescending(c => c.SubmittedAt)
                    .ToList();
            }
        }

        public List<Claim> GetCoordinatorVerifiedClaims()
        {
            lock (_lock)
            {
                return _claims
                    .Where(c => c.Status == ClaimStatus.CoordinatorVerified)
                    .OrderByDescending(c => c.CoordinatorReviewedAt)
                    .ToList();
            }
        }

        public void AddDocument(Document document)
        {
            lock (_lock)
            {
                document.DocumentId = _documentIdCounter++;
                document.UploadedAt = DateTime.Now;
                _documents.Add(document);

                // Add to claim's document list
                var claim = _claims.FirstOrDefault(c => c.ClaimId == document.ClaimId);
                if (claim != null)
                {
                    claim.Documents.Add(document);
                }
            }
        }

        public List<Document> GetDocumentsByClaimId(int claimId)
        {
            lock (_lock)
            {
                return _documents
                    .Where(d => d.ClaimId == claimId)
                    .OrderByDescending(d => d.UploadedAt)
                    .ToList();
            }
        }

        public Document? GetDocumentById(int id)
        {
            lock (_lock)
            {
                return _documents.FirstOrDefault(d => d.DocumentId == id);
            }
        }
    }
}
